/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appujianpelatihan.config;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author 
 */
public class Database {

    private static Connection connection;

    public static Connection DBConnection() {
        String dbUrl = "jdbc:mysql://localhost:3306/ujian_pelatihan";
        String user = "root";
        String password = "";

        try {
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            connection = (Connection) DriverManager.getConnection(dbUrl, user, password);
        } catch (SQLException e) {
            System.out.println("koneksi error : " + e.getMessage());
        }

        return connection;

    }

    public static void closeConnection() {
        try {
            connection.close();
        } catch (SQLException e) {
            System.out.println("FAILED TO CLOSE CONNECTION : " + e.getMessage());
        }
    }
}
